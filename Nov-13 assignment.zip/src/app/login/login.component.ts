import { Component } from '@angular/core';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {

  username: string = '';
  password: string = '';
  loginAttempts: number = 3;
  loginFailed: boolean = false;
  loginSuccess: boolean = false;

  login() {
    // Replace the condition with your actual authentication logic
    if (this.username === 'kamal' && this.password === '0123456789') {
      this.loginSuccess = true;
      this.loginFailed = false;
    } else {
      this.loginAttempts--;

      if (this.loginAttempts === 0) {
        // Disable login button after 3 failed attempts
        document.querySelector('button')?.setAttribute('disabled', 'true');
      }

      this.loginFailed = true;
      this.loginSuccess = false;
    }
  }


}
