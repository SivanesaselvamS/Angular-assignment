import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'temperature'
})
export class TemperaturePipe implements PipeTransform {

  transform(value: number, targetUnit: 'C' | 'F'): number {
    if (isNaN(value)) {
      return value;
    }

    if (targetUnit === 'C') {
      return ((value - 32) * 5) / 9;
    } else if (targetUnit === 'F') {
      return (value * 9) / 5 + 32;
    } else {
      return value;
    }
  }

}
