import { Component } from '@angular/core';

@Component({
  selector: 'app-registeration',
  templateUrl: './registeration.component.html',
  styleUrls: ['./registeration.component.css']
})
export class RegisterationComponent {

  user = {
    firstName: '',
    lastName: '',
    email: '',
    password: ''
  };

  register() {
    // Replace this with your actual registration logic
    console.log('User registered:', this.user);
  }

}
