import { NumbersonlyDirective } from './numbersonly.directive';

describe('NumbersonlyDirective', () => {
  it('should create an instance', () => {
    const directive = new NumbersonlyDirective();
    expect(directive).toBeTruthy();
  });
});
