import { Directive, HostListener } from '@angular/core';

@Directive({
  selector: '[appNumbersonly]'
})
export class NumbersonlyDirective {

  @HostListener('keypress', ['$event'])
  onKeyPress(event: KeyboardEvent): void {
    const isNumericInput = (event.key >= '0' && event.key <= '9') || event.key === '.';
    if (!isNumericInput) {
      event.preventDefault();
    }
  }

}
