import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NoWhitespaceDirective } from './no-whitespace.directive';
import { NumbersonlyDirective } from './numbersonly.directive';
import { ReadonlyDirective } from './readonly.directive';

@NgModule({
  declarations: [
    AppComponent,
    NoWhitespaceDirective,
    NumbersonlyDirective,
    ReadonlyDirective
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
